import osuCursor from './osu-cursor.js'

export default osuCursor
