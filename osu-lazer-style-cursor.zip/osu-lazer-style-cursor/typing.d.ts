export declare class osuCursor {
  constructor(option: Options)
  init(): void
  stop(): void
}

export declare type Options = {
  rotate?: boolean
}
