import o from '../src/main'

export default o
